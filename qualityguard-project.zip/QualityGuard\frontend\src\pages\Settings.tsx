import { useState, useEffect } from 'react'
import { Card, Tabs, Form, Input, Button, Switch, Space, Radio, message, Upload } from 'antd'
import { SettingOutlined, MailOutlined, SafetyOutlined, TeamOutlined, MonitorOutlined, DatabaseOutlined, PictureOutlined } from '@ant-design/icons'
import type { UploadProps } from 'antd'

const Settings: React.FC = () => {
  const [bgForm] = Form.useForm()
  const [bgType, setBgType] = useState<'gradient' | 'image'>('gradient')
  const [bgPreview, setBgPreview] = useState<string>('')

  useEffect(() => {
    // 加载现有配置
    const bgConfig = localStorage.getItem('login_background_config')
    if (bgConfig) {
      try {
        const config = JSON.parse(bgConfig)
        setBgType(config.type || 'gradient')
        bgForm.setFieldsValue({
          type: config.type || 'gradient',
          gradient: config.gradient || 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)',
          imageUrl: config.url || '',
        })
        if (config.type === 'image' && config.url) {
          setBgPreview(config.url)
        }
      } catch (e) {
        console.warn('加载背景配置失败:', e)
      }
    }
  }, [bgForm])

  const handleBgTypeChange = (e: any) => {
    setBgType(e.target.value)
  }

  const handleBgSave = () => {
    const values = bgForm.getFieldsValue()
    const config: any = {
      type: values.type || 'gradient',
    }
    if (values.type === 'gradient') {
      config.gradient = values.gradient || 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)'
    } else if (values.type === 'image') {
      config.url = values.imageUrl || bgPreview
    }
    localStorage.setItem('login_background_config', JSON.stringify(config))
    message.success('登录背景配置已保存，刷新登录页面即可看到效果')
  }

  const handleImageUpload: UploadProps['onChange'] = (info) => {
    if (info.file.status === 'done') {
      // 这里应该上传到服务器，暂时使用本地URL
      const reader = new FileReader()
      reader.onload = (e) => {
        const url = e.target?.result as string
        setBgPreview(url)
        bgForm.setFieldsValue({ imageUrl: url })
      }
      if (info.file.originFileObj) {
        reader.readAsDataURL(info.file.originFileObj)
      }
    }
  }

  const tabItems = [
    {
      key: 'system',
      label: '系统配置',
      icon: <SettingOutlined />,
      children: (
        <Card>
          <h3>基础配置</h3>
          <Form layout="vertical" style={{ maxWidth: 600 }}>
            <Form.Item label="系统名称" name="systemName">
              <Input placeholder="QualityGuard" />
            </Form.Item>
            <Form.Item label="站点URL" name="siteUrl">
              <Input placeholder="https://zhihome.com.cn" />
            </Form.Item>
            <Form.Item>
              <Button type="primary">保存配置</Button>
            </Form.Item>
          </Form>
        </Card>
      ),
    },
    {
      key: 'login_bg',
      label: '登录背景',
      icon: <PictureOutlined />,
      children: (
        <Card>
          <h3>登录页面背景配置</h3>
          <Form form={bgForm} layout="vertical" style={{ maxWidth: 600 }} onFinish={handleBgSave}>
            <Form.Item label="背景类型" name="type" initialValue="gradient">
              <Radio.Group onChange={handleBgTypeChange} value={bgType}>
                <Radio value="gradient">渐变背景</Radio>
                <Radio value="image">图片背景</Radio>
              </Radio.Group>
            </Form.Item>
            {bgType === 'gradient' && (
              <Form.Item
                label="渐变CSS"
                name="gradient"
                initialValue="linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)"
                tooltip="输入CSS渐变表达式，例如: linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
              >
                <Input.TextArea rows={3} placeholder="linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)" />
              </Form.Item>
            )}
            {bgType === 'image' && (
              <>
                <Form.Item label="图片URL" name="imageUrl">
                  <Input placeholder="输入图片URL或上传图片" />
                </Form.Item>
                <Form.Item label="上传图片">
                  <Upload
                    name="image"
                    listType="picture-card"
                    showUploadList={false}
                    onChange={handleImageUpload}
                    beforeUpload={() => false}
                  >
                    {bgPreview ? (
                      <img src={bgPreview} alt="背景预览" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    ) : (
                      <div>
                        <PictureOutlined style={{ fontSize: 24 }} />
                        <div style={{ marginTop: 8 }}>上传</div>
                      </div>
                    )}
                  </Upload>
                </Form.Item>
              </>
            )}
            <Form.Item>
              <Button type="primary" htmlType="submit">
                保存配置
              </Button>
            </Form.Item>
          </Form>
        </Card>
      ),
    },
    {
      key: 'mail',
      label: '邮件配置',
      icon: <MailOutlined />,
      children: (
        <Card>
          <h3>SMTP配置</h3>
          <Form layout="vertical" style={{ maxWidth: 600 }}>
            <Form.Item label="SMTP服务器" name="smtpHost">
              <Input placeholder="smtp.example.com" />
            </Form.Item>
            <Form.Item label="端口" name="smtpPort">
              <Input placeholder="587" />
            </Form.Item>
            <Form.Item label="用户名" name="smtpUser">
              <Input />
            </Form.Item>
            <Form.Item label="密码" name="smtpPassword">
              <Input.Password />
            </Form.Item>
            <Form.Item>
              <Space>
                <Button type="primary">保存配置</Button>
                <Button>发送测试邮件</Button>
              </Space>
            </Form.Item>
          </Form>
        </Card>
      ),
    },
    {
      key: 'security',
      label: '安全配置',
      icon: <SafetyOutlined />,
      children: (
        <Card>
          <h3>安全设置</h3>
          <Form layout="vertical" style={{ maxWidth: 600 }}>
            <Form.Item label="密码策略" name="passwordPolicy">
              <Switch checkedChildren="启用" unCheckedChildren="禁用" defaultChecked />
            </Form.Item>
            <Form.Item label="二次验证" name="twoFactor">
              <Switch checkedChildren="启用" unCheckedChildren="禁用" />
            </Form.Item>
            <Form.Item>
              <Button type="primary">保存配置</Button>
            </Form.Item>
          </Form>
        </Card>
      ),
    },
    {
      key: 'permission',
      label: '权限管理',
      icon: <TeamOutlined />,
      children: (
        <Card>
          <h3>角色管理</h3>
          <p>管理用户角色和权限</p>
        </Card>
      ),
    },
    {
      key: 'monitor',
      label: '系统监控',
      icon: <MonitorOutlined />,
      children: (
        <Card>
          <h3>服务状态</h3>
          <p>查看系统服务状态和性能指标</p>
        </Card>
      ),
    },
    {
      key: 'data',
      label: '数据管理',
      icon: <DatabaseOutlined />,
      children: (
        <Card>
          <h3>数据备份</h3>
          <p>配置数据备份和恢复策略</p>
        </Card>
      ),
    },
  ]

  return (
    <div>
      <div style={{ marginBottom: 16 }}>
        <h2>
          <SettingOutlined style={{ marginRight: 8 }} />
          系统设置
        </h2>
      </div>
      <Tabs items={tabItems} />
    </div>
  )
}

export default Settings
