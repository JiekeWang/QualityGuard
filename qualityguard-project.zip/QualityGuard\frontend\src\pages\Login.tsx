import { useState, useEffect } from 'react'
import { Form, Input, Button, Card, message, Alert } from 'antd'
import { UserOutlined, LockOutlined } from '@ant-design/icons'
import { useNavigate } from 'react-router-dom'
import { useAppDispatch, useAppSelector } from '../store/hooks'
import { loginAsync, clearError } from '../store/slices/authSlice'

const Login: React.FC = () => {
  const navigate = useNavigate()
  const dispatch = useAppDispatch()
  const { loading, error, isAuthenticated } = useAppSelector((state) => state.auth)
  const [loginForm] = Form.useForm()

  useEffect(() => {
    // 如果已经登录，重定向到dashboard
    if (isAuthenticated) {
      navigate('/dashboard')
    }
  }, [isAuthenticated, navigate])

  const onLoginFinish = async (values: { username: string; password: string }) => {
    dispatch(clearError())
    try {
      await dispatch(loginAsync(values)).unwrap()
      message.success('登录成功')
      navigate('/dashboard')
    } catch (err: any) {
      // 显示详细的错误信息
      const errorMessage = err || '登录失败，请检查用户名和密码'
      message.error(errorMessage)
      console.error('登录错误:', err)
    }
  }


  // 从localStorage读取背景配置，支持gradient和image两种类型
  const getBackgroundStyle = () => {
    const bgConfig = localStorage.getItem('login_background_config')
    if (bgConfig) {
      try {
        const config = JSON.parse(bgConfig)
        if (config.type === 'image' && config.url) {
          return {
            backgroundImage: `url(${config.url})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
          }
        } else if (config.type === 'gradient' && config.gradient) {
          return {
            background: config.gradient,
          }
        }
      } catch (e) {
        console.warn('背景配置解析失败:', e)
      }
    }
    // 默认背景
    return {
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)',
    }
  }

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        maxHeight: '100vh',
        overflow: 'hidden',
        backgroundAttachment: 'fixed',
        position: 'relative',
        ...getBackgroundStyle(),
      }}
    >
      {/* 添加装饰性光效 */}
      <div
        style={{
          position: 'absolute',
          top: '-50%',
          right: '-50%',
          width: '500px',
          height: '500px',
          background: 'radial-gradient(circle, rgba(118, 75, 162, 0.3) 0%, transparent 70%)',
          borderRadius: '50%',
          filter: 'blur(60px)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          bottom: '-50%',
          left: '-50%',
          width: '500px',
          height: '500px',
          background: 'radial-gradient(circle, rgba(102, 126, 234, 0.3) 0%, transparent 70%)',
          borderRadius: '50%',
          filter: 'blur(60px)',
        }}
      />
      <Card 
        style={{ 
          width: 400,
          position: 'relative',
          zIndex: 1,
          background: 'rgba(255, 255, 255, 0.98)',
          backdropFilter: 'blur(20px)',
          border: 'none',
          boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.5) inset',
          borderRadius: 20,
          overflow: 'hidden',
        }}
        bodyStyle={{ padding: '24px 28px' }}
      >
        {/* 顶部装饰条 */}
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: 3,
            background: 'linear-gradient(90deg, #667eea 0%, #764ba2 50%, #f093fb 100%)',
          }}
        />
        
        <div style={{ textAlign: 'center', marginBottom: 16 }}>
          <div
            style={{
              width: 48,
              height: 48,
              margin: '0 auto 8px',
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              borderRadius: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 6px 20px rgba(102, 126, 234, 0.4)',
            }}
          >
            <span style={{ fontSize: 24, fontWeight: 'bold', color: '#fff' }}>QG</span>
          </div>
          <h1 style={{ 
            fontSize: 24, 
            marginBottom: 4,
            marginTop: 0,
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            fontWeight: 800,
            letterSpacing: '-0.5px',
          }}>
            QualityGuard
          </h1>
          <p style={{ 
            color: '#9ca3af', 
            fontSize: 13, 
            fontWeight: 500,
            margin: 0,
          }}>
            自动化测试平台
          </p>
        </div>

        {error && (
          <Alert
            message={error}
            type="error"
            showIcon
            closable
            onClose={() => dispatch(clearError())}
            style={{ marginBottom: 16, fontSize: 13 }}
          />
        )}

        <Form
          form={loginForm}
          name="login"
          onFinish={onLoginFinish}
          autoComplete="off"
          size="middle"
          layout="vertical"
        >
          <Form.Item
            label={<span style={{ fontWeight: 600, color: '#374151', fontSize: 14 }}>用户名或邮箱</span>}
            name="username"
            rules={[{ required: true, message: '请输入用户名或邮箱!' }]}
            style={{ marginBottom: 12 }}
          >
            <Input
              prefix={<UserOutlined style={{ color: '#9ca3af' }} />}
              placeholder="请输入用户名或邮箱"
              style={{
                height: 40,
                borderRadius: 8,
                border: '1.5px solid #e5e7eb',
                fontSize: 14,
                paddingLeft: 12,
                backgroundColor: '#f9fafb',
              }}
            />
          </Form.Item>

          <Form.Item
            label={<span style={{ fontWeight: 600, color: '#374151', fontSize: 14 }}>密码</span>}
            name="password"
            rules={[{ required: true, message: '请输入密码!' }]}
            style={{ marginBottom: 16 }}
          >
            <Input.Password
              prefix={<LockOutlined style={{ color: '#9ca3af' }} />}
              placeholder="请输入密码"
              style={{
                height: 40,
                borderRadius: 8,
                border: '1.5px solid #e5e7eb',
                fontSize: 14,
                paddingLeft: 12,
                backgroundColor: '#f9fafb',
              }}
            />
          </Form.Item>

          <Form.Item style={{ marginBottom: 0 }}>
            <Button
              type="primary"
              htmlType="submit"
              block
              loading={loading}
              style={{
                height: 40,
                borderRadius: 8,
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                border: 'none',
                fontSize: 14,
                fontWeight: 600,
                boxShadow: '0 4px 12px rgba(102, 126, 234, 0.4)',
                transition: 'all 0.3s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)'
                e.currentTarget.style.boxShadow = '0 6px 20px rgba(102, 126, 234, 0.5)'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)'
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(102, 126, 234, 0.4)'
              }}
            >
              登录
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </div>
  )
}

export default Login

