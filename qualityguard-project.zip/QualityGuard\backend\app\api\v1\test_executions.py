"""
测试执行管理API
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import Optional, List, Any, Dict, Tuple
from datetime import datetime
import json
import httpx

from app.core.database import get_db
from app.core.dependencies import get_current_active_user
from app.models.test_execution import TestExecution, ExecutionStatus
from app.models.user import User
from app.models.environment import Environment
from app.schemas.test_execution import TestExecutionCreate, TestExecutionResponse
from app.services.report_service import ReportService

router = APIRouter()


def _extract_json_path(data: Any, path: str) -> Any:
    """非常轻量的 JSONPath 支持，只处理 $.a.b[0].c 这类常见写法。"""
    if not path or not isinstance(data, (dict, list)):
        return None
    # 兼容两种常见前缀：$.field 和 $[0].field
    if path.startswith("$."):
        path = path[2:]
    elif path.startswith("$["):
        # 去掉开头的 $，保留数组下标部分
        path = path[1:]
    parts = path.split(".")
    current: Any = data
    for part in parts:
        if current is None:
            return None
        # 处理 a[0] 这种
        if "[" in part and part.endswith("]"):
            name, index_part = part.split("[", 1)
            index_str = index_part[:-1]
            if name:
                if not isinstance(current, dict) or name not in current:
                    return None
                current = current.get(name)
            if not isinstance(current, list):
                return None
            try:
                idx = int(index_str)
            except ValueError:
                return None
            if idx < 0 or idx >= len(current):
                return None
            current = current[idx]
        else:
            if not isinstance(current, dict) or part not in current:
                return None
            current = current.get(part)
    return current


def _evaluate_assertions(
    assertions: List[Dict[str, Any]],
    http_status: Optional[int],
    response_json: Any,
) -> Tuple[bool, List[Dict[str, Any]]]:
    """根据断言规则校验响应，返回：(整体是否通过, 每条断言详情)。"""
    if not assertions:
        return True, []

    results: List[Dict[str, Any]] = []
    all_passed = True

    for item in assertions:
        a_type = (item or {}).get("type")
        passed = True
        actual: Any = None
        message = ""

        if a_type == "status_code":
            expected = item.get("expected")
            actual = http_status
            passed = http_status == expected
            if not passed:
                message = f"期望状态码为 {expected}, 实际为 {actual}"

        elif a_type == "response_body":
            path = item.get("path") or ""
            operator = item.get("operator") or "equal"
            expected = item.get("expected")
            actual = _extract_json_path(response_json, path)

            if operator == "equal":
                passed = actual == expected
            elif operator == "not_equal":
                passed = actual != expected
            elif operator == "contains":
                if isinstance(actual, (list, str)):
                    passed = expected in actual
                else:
                    passed = False
            elif operator == "not_contains":
                if isinstance(actual, (list, str)):
                    passed = expected not in actual
                else:
                    passed = False
            elif operator == "gt":
                try:
                    passed = actual > expected
                except Exception:
                    passed = False
            elif operator == "lt":
                try:
                    passed = actual < expected
                except Exception:
                    passed = False
            else:
                # 未知运算符，视为失败
                passed = False
                message = f"不支持的运算符: {operator}"

            if not passed and not message:
                message = f"路径 {path} 断言失败，期望 {operator} {expected}，实际值为 {actual!r}"

        else:
            # 其他类型暂时标记为未实现
            passed = False
            message = f"断言类型 {a_type!r} 暂未实现"

        if not passed:
            all_passed = False

        results.append(
            {
                **(item or {}),
                "actual": actual,
                "passed": passed,
                "message": message,
            }
        )

    return all_passed, results


@router.get("/", response_model=List[TestExecutionResponse])
async def get_test_executions(
    project_id: Optional[int] = Query(None, description="项目ID"),
    test_case_id: Optional[int] = Query(None, description="测试用例ID"),
    status: Optional[ExecutionStatus] = Query(None, description="执行状态"),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取测试执行列表"""
    query = select(TestExecution)
    conditions = []
    
    if project_id:
        conditions.append(TestExecution.project_id == project_id)
    if test_case_id:
        conditions.append(TestExecution.test_case_id == test_case_id)
    if status:
        conditions.append(TestExecution.status == status)
    
    if conditions:
        query = query.where(and_(*conditions))
    
    query = query.offset(skip).limit(limit).order_by(TestExecution.created_at.desc())
    
    result = await db.execute(query)
    executions = result.scalars().all()
    return executions


@router.post("/", response_model=TestExecutionResponse, status_code=status.HTTP_201_CREATED)
async def create_test_execution(
    execution: TestExecutionCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """创建测试执行"""
    # 检查测试用例是否存在
    from app.models.test_case import TestCase
    case_result = await db.execute(select(TestCase).where(TestCase.id == execution.test_case_id))
    test_case = case_result.scalar_one_or_none()
    if not test_case:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="测试用例不存在"
        )
    
    # 检查项目是否存在
    from app.models.project import Project
    project_result = await db.execute(select(Project).where(Project.id == execution.project_id))
    project = project_result.scalar_one_or_none()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="项目不存在"
        )

    # 从测试用例配置中提取请求信息，用于真实请求及日志展示
    request_info: Dict[str, Any] = {}
    request_cfg: Dict[str, Any] = {}
    assertions_cfg: List[Dict[str, Any]] = []
    if isinstance(test_case.config, dict):
        request_cfg = test_case.config.get("request") or {}
        interface_cfg = test_case.config.get("interface") or {}
        raw_assertions = test_case.config.get("assertions") or []
        if isinstance(raw_assertions, list):
            assertions_cfg = raw_assertions

        method = interface_cfg.get("method") or request_cfg.get("method") or "GET"
        path = interface_cfg.get("path") or request_cfg.get("path") or ""

        request_info = {
            "method": method,
            "path": path,
            "headers": request_cfg.get("headers") or {},
            "params": request_cfg.get("params") or {},
            "path_params": request_cfg.get("path_params") or {},
            "body": request_cfg.get("body") or request_cfg.get("data") or None,
        }

    # 创建测试执行
    new_execution = TestExecution(
        **execution.dict(),
        status=ExecutionStatus.RUNNING,
        started_at=datetime.utcnow(),
        logs="测试执行已启动",
        result=None,
    )
    
    db.add(new_execution)
    await db.commit()
    await db.refresh(new_execution)

    # 构造真实 HTTP 请求（当前同步执行单接口请求）
    lines = []
    lines.append("== 测试执行已启动 ==")
    lines.append(f"执行ID: {new_execution.id}")
    lines.append(f"项目: {project.id} - {project.name}")
    lines.append(f"测试用例ID: {test_case.id} - {test_case.name}")
    if execution.environment:
        lines.append(f"执行环境: {execution.environment}")
    lines.append("")

    # 计算目标 URL（优先使用环境 base_url）
    base_url: str = ""
    env_obj: Optional[Environment] = None
    if execution.environment:
        env_result = await db.execute(
            select(Environment).where(Environment.key == execution.environment)
        )
        env_obj = env_result.scalar_one_or_none()
        if env_obj and env_obj.base_url:
            base_url = env_obj.base_url.rstrip("/")

    path = request_info.get("path") or ""
    if path and not path.startswith("http"):
        if not path.startswith("/"):
            path = "/" + path
        if base_url:
            url = base_url + path
        else:
            # 如果没有配置环境 base_url，尝试使用请求配置里的 full_url 或原始 path
            url = request_cfg.get("url") or path
    else:
        url = path or request_cfg.get("url") or ""

    # 合并 headers / params（环境默认 + 用例配置）
    headers: Dict[str, Any] = {}
    params: Dict[str, Any] = {}
    if env_obj and isinstance(env_obj.default_headers, dict):
        headers.update(env_obj.default_headers)
    if env_obj and isinstance(env_obj.default_params, dict):
        params.update(env_obj.default_params)
    if request_info.get("headers"):
        headers.update(request_info["headers"])
    if request_info.get("params"):
        params.update(request_info["params"])

    body = request_info.get("body")

    http_status: Optional[int] = None
    response_text: Optional[str] = None
    response_json: Optional[Any] = None
    error_message: Optional[str] = None

    if request_info:
        lines.append("== 请求信息 ==")
        lines.append(f"请求方法: {request_info.get('method')}")
        lines.append(f"请求URL: {url or (request_info.get('path') or '')}")
        if request_info.get("headers"):
            lines.append("请求头:")
            lines.append(json.dumps(request_info["headers"], ensure_ascii=False, indent=2))
        if request_info.get("params"):
            lines.append("Query 参数:")
            lines.append(json.dumps(request_info["params"], ensure_ascii=False, indent=2))
        if request_info.get("path_params"):
            lines.append("Path 参数:")
            lines.append(json.dumps(request_info["path_params"], ensure_ascii=False, indent=2))
        if body is not None:
            lines.append("请求 Body:")
            lines.append(json.dumps(body, ensure_ascii=False, indent=2))
        lines.append("")

    # 执行 HTTP 请求
    try:
        async with httpx.AsyncClient(timeout=30.0, verify=False) as client:
            method = (request_info.get("method") or "GET").upper()
            if method in ("GET", "DELETE"):
                resp = await client.request(method, url, headers=headers, params=params)
            else:
                resp = await client.request(
                    method,
                    url,
                    headers=headers,
                    params=params,
                    json=body,
                )
        http_status = resp.status_code
        response_text = resp.text
        try:
            response_json = resp.json()
        except Exception:
            response_json = None

        lines.append("== 响应信息（真实请求） ==")
        lines.append(f"HTTP 状态码: {http_status}")
        if response_json is not None:
            lines.append("响应 Body(JSON):")
            lines.append(json.dumps(response_json, ensure_ascii=False, indent=2))
        else:
            lines.append("响应 Body(文本):")
            lines.append(response_text or "")

    except Exception as exc:  # noqa: BLE001
        error_message = str(exc)
        lines.append("== 请求执行失败 ==")
        lines.append(f"错误信息: {error_message}")

    # 基于断言 & HTTP 结果计算执行状态
    assertions_passed = True
    assertion_results: List[Dict[str, Any]] = []

    lines.append("")
    lines.append("== 断言配置检查 ==")
    lines.append(f"从用例配置中读取到的断言数量: {len(assertions_cfg)}")
    if assertions_cfg:
        lines.append("断言配置详情:")
        for idx, a in enumerate(assertions_cfg, start=1):
            lines.append(f"  [{idx}] {json.dumps(a, ensure_ascii=False)}")
        
        assertions_passed, assertion_results = _evaluate_assertions(
            assertions_cfg, http_status, response_json
        )
        lines.append("")
        lines.append("== 断言执行结果 ==")
        for idx, ar in enumerate(assertion_results, start=1):
            status_text = "通过" if ar.get("passed") else "失败"
            a_type = ar.get("type", "unknown")
            expected = ar.get("expected", "N/A")
            actual = ar.get("actual", "N/A")
            path = ar.get("path", "")
            operator = ar.get("operator", "")
            
            lines.append(f"[{idx}] 类型={a_type} 结果={status_text}")
            if path:
                lines.append(f"    路径: {path}")
            if operator:
                lines.append(f"    运算符: {operator}")
            lines.append(f"    期望值: {expected}")
            lines.append(f"    实际值: {actual}")
            if ar.get("message"):
                lines.append(f"    说明: {ar['message']}")
        
        lines.append("")
        lines.append(f"断言整体结果: {'全部通过' if assertions_passed else '存在失败'}")
    else:
        lines.append("未配置断言，使用默认判断逻辑（HTTP状态码 < 400 视为通过）")
        # 未配置断言时，保持原有行为：HTTP < 400 视为通过
        if http_status is not None and http_status < 400 and not error_message:
            assertions_passed = True
        else:
            assertions_passed = False

    # 组装执行结果摘要
    if assertions_passed and not error_message:
        summary = {"total": 1, "passed": 1, "failed": 0, "skipped": 0}
        status_value = ExecutionStatus.PASSED
    else:
        summary = {"total": 1, "passed": 0, "failed": 1, "skipped": 0}
        status_value = ExecutionStatus.FAILED

    result_payload = {
        "summary": summary,
        "details": [
            {
                "step": 1,
                "name": "HTTP 请求",
                "status": "passed" if status_value == ExecutionStatus.PASSED else "failed",
                "request": {
                    "url": url,
                    "method": request_info.get("method") if request_info else None,
                    "headers": headers,
                    "params": params,
                    "body": body,
                },
                "response": {
                    "status_code": http_status,
                    "body_json": response_json,
                    "body_text": response_text,
                    "error": error_message,
                },
                "assertions": assertion_results,
            }
        ],
    }

    lines.append("")
    lines.append("== 执行结果摘要 ==")
    lines.append(
        f"total={summary['total']}, passed={summary['passed']}, "
        f"failed={summary['failed']}, skipped={summary['skipped']}"
    )

    new_execution.logs = "\n".join(lines)
    new_execution.status = status_value
    new_execution.finished_at = datetime.utcnow()
    new_execution.result = result_payload

    await db.commit()
    await db.refresh(new_execution)
    
    # 生成对应的报告视图（当前实现为基于执行记录的动态报告，不单独落库）
    report_service = ReportService()
    await report_service.generate_report(db=db, execution_id=new_execution.id)
    
    return new_execution


@router.get("/{execution_id}", response_model=TestExecutionResponse)
async def get_test_execution(
    execution_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取测试执行详情"""
    result = await db.execute(select(TestExecution).where(TestExecution.id == execution_id))
    execution = result.scalar_one_or_none()
    
    if not execution:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="测试执行不存在"
        )
    
    return execution


@router.get("/{execution_id}/logs")
async def get_execution_logs(
    execution_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """获取测试执行日志"""
    result = await db.execute(select(TestExecution).where(TestExecution.id == execution_id))
    execution = result.scalar_one_or_none()
    
    if not execution:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="测试执行不存在"
        )
    
    return {
        "execution_id": execution_id,
        "logs": execution.logs or "",
        "status": execution.status
    }
