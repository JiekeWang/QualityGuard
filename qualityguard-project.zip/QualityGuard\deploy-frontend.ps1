# QualityGuard Frontend Deployment Script
# 部署构建好的前端文件到服务器

$ServerIP = "47.116.197.230"
$ServerUser = "root"
$ServerPassword = "232629wh@"

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "QualityGuard Frontend Deployment" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# Check if frontend/dist exists
$distPath = "D:\QualityGuard\frontend\dist"
if (-not (Test-Path $distPath)) {
    Write-Host "[ERROR] Frontend dist directory not found: $distPath" -ForegroundColor Red
    Write-Host "Please run 'npm run build' in frontend directory first" -ForegroundColor Yellow
    exit 1
}

Write-Host "[OK] Frontend dist directory found" -ForegroundColor Green
Write-Host ""

# Compress frontend dist
Write-Host "Step 1: Compressing frontend dist..." -ForegroundColor Yellow
$distZip = "frontend-dist.zip"
if (Test-Path $distZip) {
    Remove-Item $distZip -Force
}

# Use 7zip if available, otherwise use PowerShell
if (Get-Command 7z -ErrorAction SilentlyContinue) {
    & 7z a -tzip $distZip "$distPath\*" -r
} else {
    # Use PowerShell compression with proper path handling
    $tempZip = Join-Path $env:TEMP "frontend-dist-temp.zip"
    if (Test-Path $tempZip) {
        Remove-Item $tempZip -Force
    }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::CreateFromDirectory($distPath, $tempZip)
    Move-Item $tempZip $distZip -Force
}
if ($LASTEXITCODE -eq 0) {
    $zipSize = (Get-Item $distZip).Length / 1MB
    Write-Host "[OK] Frontend dist compressed: $distZip ($([math]::Round($zipSize, 2)) MB)" -ForegroundColor Green
} else {
    Write-Host "[ERROR] Compression failed" -ForegroundColor Red
    exit 1
}
Write-Host ""

# Upload to server
Write-Host "Step 2: Uploading to server..." -ForegroundColor Yellow
Write-Host "Server: $ServerIP" -ForegroundColor Gray
Write-Host "Uploading file: $distZip" -ForegroundColor Gray
Write-Host "This may take a few minutes..." -ForegroundColor Gray

# Use SCP to upload
$scpCommand = "scp"
$scpArgs = @(
    "-o", "StrictHostKeyChecking=no",
    $distZip,
    "${ServerUser}@${ServerIP}:/root/"
)

# Try to use sshpass if available, otherwise prompt for password
$env:SSH_ASKPASS_REQUIRE = "never"
& $scpCommand $scpArgs

if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Upload failed" -ForegroundColor Red
    Write-Host "Please check network connection or server status" -ForegroundColor Yellow
    Write-Host "You may need to enter password manually: $ServerPassword" -ForegroundColor Yellow
    exit 1
}

Write-Host "[OK] Upload successful" -ForegroundColor Green
Write-Host ""

# Generate deployment script for server
Write-Host "Step 3: Generating server deployment script..." -ForegroundColor Yellow
$deployScript = @"
#!/bin/bash
# Frontend deployment script for server

set -e

echo "=========================================="
echo "Deploying Frontend to Server"
echo "=========================================="
echo ""

PROJECT_PATH="/root/QualityGuard"
DIST_ZIP="/root/frontend-dist.zip"

# Extract frontend dist
echo "Step 1: Extracting frontend dist..."
cd /root
if [ -f "\$DIST_ZIP" ]; then
    unzip -o \$DIST_ZIP -d /tmp/frontend-dist
    echo "[OK] Extracted frontend dist"
else
    echo "[ERROR] Frontend dist zip not found: \$DIST_ZIP"
    exit 1
fi
echo ""

# Check if using Docker
if [ -f "\$PROJECT_PATH/docker-compose.yml" ]; then
    echo "Step 2: Deploying to Docker..."
    cd \$PROJECT_PATH
    
    # Copy to Docker volume or rebuild frontend container
    if docker ps | grep -q qualityguard-frontend; then
        echo "Frontend container is running, copying files..."
        docker cp /tmp/frontend-dist/. qualityguard-frontend:/usr/share/nginx/html/
        docker restart qualityguard-frontend
        echo "[OK] Frontend container updated"
    else
        echo "Frontend container not running, rebuilding..."
        cd \$PROJECT_PATH/frontend
        if [ -d "dist" ]; then
            rm -rf dist
        fi
        cp -r /tmp/frontend-dist dist
        cd \$PROJECT_PATH
        docker compose build frontend
        docker compose up -d frontend
        echo "[OK] Frontend container rebuilt and started"
    fi
else
    echo "Step 2: Deploying to Nginx (non-Docker)..."
    # Copy to Nginx directory
    mkdir -p /usr/share/nginx/html/qualityguard
    rm -rf /usr/share/nginx/html/qualityguard/*
    cp -r /tmp/frontend-dist/* /usr/share/nginx/html/qualityguard/
    chown -R nginx:nginx /usr/share/nginx/html/qualityguard
    echo "[OK] Frontend files copied to Nginx"
    
    # Restart Nginx
    systemctl restart nginx
    echo "[OK] Nginx restarted"
fi
echo ""

# Cleanup
echo "Step 3: Cleaning up..."
rm -rf /tmp/frontend-dist
rm -f \$DIST_ZIP
echo "[OK] Cleanup completed"
echo ""

echo "=========================================="
echo "[SUCCESS] Frontend deployment completed!"
echo "=========================================="
echo ""
echo "Access: https://zhihome.com.cn"
echo ""
"@

$deployScript | Out-File -FilePath "deploy-frontend-server.sh" -Encoding UTF8
Write-Host "[OK] Server deployment script generated" -ForegroundColor Green
Write-Host ""

# Upload deployment script
Write-Host "Step 4: Uploading deployment script..." -ForegroundColor Yellow
& $scpCommand -o "StrictHostKeyChecking=no" "deploy-frontend-server.sh" "${ServerUser}@${ServerIP}:/root/"
if ($LASTEXITCODE -eq 0) {
    Write-Host "[OK] Deployment script uploaded" -ForegroundColor Green
} else {
    Write-Host "[WARNING] Deployment script upload failed, but you can create it manually on server" -ForegroundColor Yellow
}
Write-Host ""

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "[SUCCESS] Local preparation completed!" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps: Execute these commands on the server:" -ForegroundColor Yellow
Write-Host ""
Write-Host "# 1. SSH login to server" -ForegroundColor White
Write-Host "ssh $ServerUser@$ServerIP" -ForegroundColor White
Write-Host ""
Write-Host "# 2. Run deployment script" -ForegroundColor White
Write-Host "chmod +x /root/deploy-frontend-server.sh" -ForegroundColor White
Write-Host "/root/deploy-frontend-server.sh" -ForegroundColor White
Write-Host ""
Write-Host "Or manually:" -ForegroundColor White
Write-Host "cd /root" -ForegroundColor White
Write-Host "unzip -o frontend-dist.zip -d /tmp/frontend-dist" -ForegroundColor White
Write-Host "# For Docker:" -ForegroundColor Gray
Write-Host "docker cp /tmp/frontend-dist/. qualityguard-frontend:/usr/share/nginx/html/" -ForegroundColor Gray
Write-Host "docker restart qualityguard-frontend" -ForegroundColor Gray
Write-Host "# For non-Docker:" -ForegroundColor Gray
Write-Host "cp -r /tmp/frontend-dist/* /usr/share/nginx/html/qualityguard/" -ForegroundColor Gray
Write-Host "systemctl restart nginx" -ForegroundColor Gray
Write-Host ""

Read-Host "Press any key to continue..."

