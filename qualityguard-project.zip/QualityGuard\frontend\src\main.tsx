import React from 'react'
import ReactDOM from 'react-dom/client'
import { Provider } from 'react-redux'
import { ConfigProvider, theme } from 'antd'
import zhCN from 'antd/locale/zh_CN'
import App from './App'
import { store } from './store'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Provider store={store}>
      <ConfigProvider 
        locale={zhCN}
        theme={{
          algorithm: theme.darkAlgorithm,
          token: {
            colorBgBase: '#0f1419',
            colorBgContainer: '#1e2329',
            colorBgElevated: '#252b3a',
            colorText: '#e4e7eb',
            colorTextSecondary: '#9ca3af',
            colorTextTertiary: '#6b7280',
            colorBorder: '#2d3748',
            colorBorderSecondary: '#1e2329',
            colorPrimary: '#3b82f6',
            colorSuccess: '#10b981',
            colorWarning: '#f59e0b',
            colorError: '#ef4444',
            colorInfo: '#3b82f6',
            borderRadius: 8,
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.3)',
            boxShadowSecondary: '0 4px 16px rgba(0, 0, 0, 0.4)',
            // 输入框文字颜色配置
            colorTextPlaceholder: '#6b7280',
            colorTextHeading: '#ffffff',
          },
          components: {
            Input: {
              colorText: '#1f2937',
              colorTextPlaceholder: '#9ca3af',
              colorBgContainer: '#f9fafb',
              colorBorder: '#e5e7eb',
              colorBorderHover: '#667eea',
              colorPrimaryHover: '#667eea',
              activeBorderColor: '#667eea',
            },
            InputNumber: {
              colorText: '#1f2937',
              colorTextPlaceholder: '#9ca3af',
              colorBgContainer: '#f9fafb',
              colorBorder: '#e5e7eb',
            },
            TextArea: {
              colorText: '#1f2937',
              colorTextPlaceholder: '#9ca3af',
              colorBgContainer: '#f9fafb',
              colorBorder: '#e5e7eb',
            },
            Select: {
              colorText: '#1f2937',
              colorTextPlaceholder: '#9ca3af',
              colorBgContainer: '#f9fafb',
              colorBorder: '#e5e7eb',
            },
          },
        }}
      >
        <App />
      </ConfigProvider>
    </Provider>
  </React.StrictMode>,
)

